<h1>Praktikum Web Lanjut - CI MVC</h1>
<h2>Nama: Mahfudz Aji W.M.N.</h2>
<h2>NIM: 21.22.2455</h2>
<h2>Angkatan: 2021</h2>