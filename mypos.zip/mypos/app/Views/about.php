<?php
    echo view('header');
    echo "<h1>Halaman about</h1>";
    echo "Nama mahasiswa: ";
    echo ul($nama);
    echo view('footer');

?>